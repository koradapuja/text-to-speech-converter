document.querySelector('.close-btn').addEventListener('click', () => {
    document.getElementById('email-popup').style.display = 'none';
});

document.getElementById('submit-email-btn').addEventListener('click', () => {
    const email = document.getElementById('email-input').value;
    if (email) {
        alert(`Email submitted: ${email}`);
        document.getElementById('email-popup').style.display = 'none';
    } else {
        alert('Please enter a valid email.');
    }
});
document.addEventListener('DOMContentLoaded', function() {
    const languageSelect = document.getElementById('languageSelect');
    const speakButton = document.getElementById('speakButton');
    const textInput = document.getElementById('textInput');
    
    function populateVoices() {
        const voices = speechSynthesis.getVoices();
        
        // Clear existing options
        languageSelect.innerHTML = '';

        // Populate the dropdown with available voices
        voices.forEach(voice => {
            const option = document.createElement('option');
            option.value = voice.name;
            option.textContent = `${voice.name} (${voice.lang})`;
            languageSelect.appendChild(option);
        });
    }

    // Populate voices on page load
    populateVoices();
    
    // Re-populate voices when the list is updated (e.g., after loading)
    speechSynthesis.onvoiceschanged = populateVoices;

    speakButton.addEventListener('click', function() {
        const selectedVoiceName = languageSelect.value;
        const voices = speechSynthesis.getVoices();
        const selectedVoice = voices.find(voice => voice.name === selectedVoiceName);
        
        if (!selectedVoice) {
            alert('Please select a valid voice.');
            return;
        }

        const text = textInput.value;
        if (text === '') {
            alert('Please enter some text.');
            return;
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = selectedVoice;

        // Optional: Set some properties
        utterance.rate = 1; // Speed of the speech
        utterance.pitch = 1; // Pitch of the speech

        // Speak the text
        speechSynthesis.speak(utterance);
    });
});







