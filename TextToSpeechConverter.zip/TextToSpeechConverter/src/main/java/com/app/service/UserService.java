package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.UserEntity;
import com.app.repo.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;
	
	public void saveUser(String email) {
		UserEntity userEmail=new UserEntity();
		userEmail.setEmail(email);
		repo.save(userEmail);
	}
}
