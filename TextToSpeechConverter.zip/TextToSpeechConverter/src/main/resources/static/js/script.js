
document.addEventListener('DOMContentLoaded', function() {
    const languageSelect = document.getElementById('languageSelect');
    const speakButton = document.getElementById('speakButton');
    const textInput = document.getElementById('textInput');
    
    function populateVoices() {
        const voices = speechSynthesis.getVoices();
        
        languageSelect.innerHTML = '';

        voices.forEach(voice => {
            const option = document.createElement('option');
            option.value = voice.name;
            option.textContent = `${voice.name} (${voice.lang})`;
            languageSelect.appendChild(option);
        });
    }

    populateVoices();
    
    speechSynthesis.onvoiceschanged = populateVoices;

    speakButton.addEventListener('click', function() {
        const selectedVoiceName = languageSelect.value;
        const voices = speechSynthesis.getVoices();
        const selectedVoice = voices.find(voice => voice.name === selectedVoiceName);
        
        if (!selectedVoice) {
            alert('Please select a valid voice.');
            return;
        }

        const text = textInput.value;
        if (text === '') {
            alert('Please enter some text.');
            return;
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = selectedVoice;

        utterance.rate = 1;
        utterance.pitch = 1;

        speechSynthesis.speak(utterance);
    });
});
